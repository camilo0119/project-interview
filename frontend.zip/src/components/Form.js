import React, { useState} from 'react'

export const Form = () => {

  const [dataForm, setdataForm] = useState()

  const handleInputChange = (e) => {
    const {value, name} = e.target
    setdataForm(old => ({
      ...dataForm,
      [name]: value
    }))
  }

  const handleSubmit = () => {}

  return (
    <div>
      <Form>
        <input name="email" value={dataForm.email} onChange={handleInputChange}/>
        <input name="name" onChange={handleInputChange} />
        <input name="dateOfBirth" onChange={handleInputChange} />
        <button onClick={handleSubmit} />
      </Form>
    </div>
  )
}
