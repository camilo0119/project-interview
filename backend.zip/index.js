const express = require('express')
const { dbConnection } = require('./src/config/dbconfig')

const app = express()

dbConnection()

app.use(express.json())

app.use('/users', require('./src/routes/users'))

app.listen(4000, () => {
  console.log('Server in port: ' + 4000)
})