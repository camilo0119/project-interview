const {Router} = require('express')
const { createNewUser, listAllUsers } = require('../constrollers/users')

const router = Router()

router.post('/', createNewUser)
router.get('/', listAllUsers)

module.exports = router