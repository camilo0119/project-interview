const db = require('mongoose')

const dbConnection = async () => {
  try
 {

    await db.connect('mongodb+srv://camilo_0119:6604107@cluster0.3f3yn.mongodb.net/test-k4', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    // useCreateIndex: true
  })
  console.log('Database is connected!')

 } catch (e) {
   console.log(e)
 }


}

module.exports = {
  dbConnection
}