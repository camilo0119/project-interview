const { Schema, model } = require("mongoose");

const User = Schema({
  email: {
    type: String,
    require: true
  },
  name: {
    type: String,
    require: true
  },
  dateOfBirth: {
    type: Date,
    require: true
  }
})

module.exports =  model("User", User)
