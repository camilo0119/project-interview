const UserModel = require("../models/User")


const createNewUser = async (req, res) => {

  const newUser = new UserModel(req.body)

  try {
    await newUser.save()
    res.status(200).json({
      ok: true
    })
  } catch (e) {
    res.status(400).json({
      ok: false,
      message: e
    })
  }

}

const listAllUsers = async (req, res) => {

  try {
    const allUsers = await UserModel.find({})
    res.status(200).json({
      ok: true,
      userList: allUsers
    })
  } catch (e) {
    res.status(500).json({
      ok: false,
      message: e
    })
  }
}

module.exports = {
  listAllUsers,
  createNewUser
}